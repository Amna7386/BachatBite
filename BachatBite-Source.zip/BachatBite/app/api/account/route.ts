import {getChatGPTUser} from '../../chatgpt-auth';
import {database} from '@/lib/db';
import {getProfile} from '@/lib/account';
export async function POST(req:Request){
 try{
  if(req.headers.get('origin')&&req.headers.get('origin')!==new URL(req.url).origin)return Response.json({error:'Invalid request origin.'},{status:403});
  const user=await getChatGPTUser();if(!user)return Response.json({error:'Please sign in with ChatGPT first.'},{status:401});
  const p=await req.json() as any;
  const name=typeof p.name==='string'?p.name.trim():'';
  if(name.length<2||name.length>80||/[\x00-\x1F]/.test(name))return Response.json({error:'Enter your name (2–80 characters).'},{status:400});
  if(!['customer','seller'].includes(p.role))return Response.json({error:'Choose how you want to start.'},{status:400});
  await database().prepare('INSERT INTO profiles (user_id,name,role,created) VALUES (?,?,?,?) ON CONFLICT(user_id) DO NOTHING').bind(user.userId,name,p.role,new Date().toISOString()).run();
  return Response.json({profile:await getProfile(user.userId)},{headers:{'Cache-Control':'no-store'}});
 }catch(e){console.error(e);return Response.json({error:'Could not create your profile. Your details are still here; please try again.'},{status:503});}
}
