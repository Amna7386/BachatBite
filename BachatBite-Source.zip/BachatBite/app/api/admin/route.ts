import {getChatGPTUser} from '@/app/chatgpt-auth';
import {isAdmin} from '@/lib/admin';
import {database} from '@/lib/db';
export const dynamic='force-dynamic';
const reports={
 users:{from:'profiles p',fields:'p.user_id AS id,p.name,p.role,p.created',search:'p.name || p.user_id || p.role',order:'p.created'},
 stores:{from:'stores s LEFT JOIN profiles p ON p.user_id=s.owner',fields:"s.id,s.name,COALESCE(p.name,s.owner) AS owner,s.area,s.address,s.contact,CASE WHEN s.sample=1 THEN 'Sample' ELSE 'Real' END AS type",search:"s.name || s.area || s.contact || COALESCE(p.name,'')",order:'s.rowid'},
 listings:{from:'listings l JOIN stores s ON s.id=l.store_id',fields:"l.id,l.title,s.name AS restaurant,l.price,l.quantity,l.end AS pickup_end,CASE WHEN s.sample=1 THEN 'Sample' ELSE 'Real' END AS type",search:'l.title || s.name',order:'l.created'},
 orders:{from:'reservations r JOIN listings l ON l.id=r.listing_id JOIN stores s ON s.id=l.store_id LEFT JOIN profiles p ON p.user_id=r.customer',fields:"r.id,COALESCE(p.name,r.customer) AS customer,s.name AS restaurant,l.title,r.quantity,r.price*r.quantity AS total,r.status,r.created,CASE WHEN s.sample=1 THEN 'Sample' ELSE 'Real' END AS type",search:"r.id || COALESCE(p.name,'') || s.name || l.title || r.status",order:'r.created'},
};
export async function GET(request:Request){
 const user=await getChatGPTUser();
 const respond=(body:unknown,status=200)=>Response.json(body,{status,headers:{'Cache-Control':'private, no-store'}});
 if(!user)return respond({error:'Sign in required'},401);
 if(!isAdmin(user))return respond({error:'Owner access only'},403);
 const url=new URL(request.url),kind=url.searchParams.get('kind')||'orders';
 if(!Object.hasOwn(reports,kind))return respond({error:'Invalid report'},400);
 const report=reports[kind as keyof typeof reports];
 const page=Math.max(1,Math.min(100000,Number.parseInt(url.searchParams.get('page')||'1',10)||1));
 const search='%'+(url.searchParams.get('q')||'').slice(0,100)+'%';
 try{
  const db=database();
  const [rows,total,summary]=await Promise.all([
   db.prepare(`SELECT ${report.fields} FROM ${report.from} WHERE (${report.search}) LIKE ? ORDER BY ${report.order} DESC LIMIT 25 OFFSET ?`).bind(search,(page-1)*25).all(),
   db.prepare(`SELECT COUNT(*) AS count FROM ${report.from} WHERE (${report.search}) LIKE ?`).bind(search).first(),
   db.prepare("SELECT (SELECT COUNT(*) FROM profiles) AS users,(SELECT COUNT(*) FROM stores WHERE sample=0) AS restaurants,(SELECT COUNT(*) FROM reservations r JOIN listings l ON l.id=r.listing_id JOIN stores s ON s.id=l.store_id WHERE s.sample=0) AS orders,(SELECT COALESCE(SUM(r.quantity*r.price),0) FROM reservations r JOIN listings l ON l.id=r.listing_id JOIN stores s ON s.id=l.store_id WHERE s.sample=0 AND r.status='collected') AS collected_value").first()
  ]);
  return respond({rows:rows.results,total:Number(total?.count||0),page,summary});
 }catch{return respond({error:'Could not load dashboard. Please try again.'},503)}
}
