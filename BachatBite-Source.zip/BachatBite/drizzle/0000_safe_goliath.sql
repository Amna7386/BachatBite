CREATE TABLE `listings` (
	`id` text PRIMARY KEY NOT NULL,
	`store_id` text NOT NULL,
	`title` text NOT NULL,
	`description` text NOT NULL,
	`category` text NOT NULL,
	`price` integer NOT NULL,
	`original_price` integer NOT NULL,
	`quantity` integer NOT NULL,
	`ingredients` text NOT NULL,
	`photo` text NOT NULL,
	`start` text NOT NULL,
	`end` text NOT NULL,
	`created` text NOT NULL,
	FOREIGN KEY (`store_id`) REFERENCES `stores`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `listings_store_idx` ON `listings` (`store_id`);--> statement-breakpoint
CREATE TABLE `reservations` (
	`id` text PRIMARY KEY NOT NULL,
	`listing_id` text NOT NULL,
	`customer` text NOT NULL,
	`quantity` integer NOT NULL,
	`price` integer NOT NULL,
	`original_price` integer NOT NULL,
	`code` text NOT NULL,
	`status` text DEFAULT 'reserved' NOT NULL,
	`created` text NOT NULL,
	FOREIGN KEY (`listing_id`) REFERENCES `listings`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `reservations_customer_idx` ON `reservations` (`customer`);--> statement-breakpoint
CREATE INDEX `reservations_listing_idx` ON `reservations` (`listing_id`);--> statement-breakpoint
CREATE TABLE `stores` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`name` text NOT NULL,
	`area` text NOT NULL,
	`address` text NOT NULL,
	`contact` text NOT NULL,
	`sample` integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE INDEX `stores_owner_idx` ON `stores` (`owner`);