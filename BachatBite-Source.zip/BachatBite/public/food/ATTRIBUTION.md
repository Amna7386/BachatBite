# BachatBite demo food imagery

These are illustrative stock photos, not photos of partner meals. Unsplash free-download search listings were used (not Unsplash+). Unsplash license: https://unsplash.com/license . Attribution is appreciated; retain this source record with the project.

| File | Photographer | Source | Dimensions |
|---|---|---|---|
| sandwich.jpg | Mae Mu | https://unsplash.com/photos/IZ0LRt1khgM | 1200 × 960 |
| pastries.jpg | Kyle Hinkson | https://unsplash.com/photos/a-croissant-on-a-plate-next-to-a-pastry-on-a-plate-EbHAkwJUMnY | 1200 × 1800 |
| rice.jpg | Rashpal Singh | https://unsplash.com/photos/3tpobXvtAEw | 1200 × 800 |

Sandwich meat type is not verified. Do not use the photo as proof of halal status or label it as a verified chicken sandwich. Pastries show croissant and fig toast; rice photo shows biryani in a catering tray.

Retrieved 2026-10-03. Direct CDN sources:
- https://images.unsplash.com/photo-1553909489-cd47e0907980
- https://images.unsplash.com/photo-1695298242998-6d0ad6a79a14
- https://images.unsplash.com/photo-1697155406055-2db32d47ca07
