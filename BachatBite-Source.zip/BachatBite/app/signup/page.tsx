import AccountEntry from '../account-entry';
export const dynamic='force-dynamic';
export const metadata={title:'Create account | BachatBite'};
export default function Signup(){return <AccountEntry mode="signup"/>}
