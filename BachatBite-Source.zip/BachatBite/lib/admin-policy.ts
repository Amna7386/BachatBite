export function isAdminEmail(email: string | null | undefined, configured: unknown): boolean {
  return typeof configured === 'string' && configured.trim().length > 0 && typeof email === 'string' && email.trim().toLowerCase() === configured.trim().toLowerCase();
}
