import AccountEntry from '../account-entry';
export const dynamic='force-dynamic';
export const metadata={title:'Log in | BachatBite'};
export default function Login(){return <AccountEntry mode="login"/>}
