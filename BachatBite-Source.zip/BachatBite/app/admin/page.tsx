import {requireChatGPTUser} from '../chatgpt-auth';
import {isAdmin} from '@/lib/admin';
import AdminDashboard from './ui';
export const dynamic='force-dynamic';
export default async function AdminPage(){
  const user=await requireChatGPTUser('/admin');
  if(!isAdmin(user))return <main className="empty"><h1>Owner access only</h1><p>This account cannot view the administration dashboard.</p><a className="button primary" href="/">Back to BachatBite</a></main>;
  return <AdminDashboard/>;
}
