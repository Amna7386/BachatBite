import {isAdmin} from '@/lib/admin';
import BachatApp from './ui';
import {getChatGPTUser,chatGPTSignInPath} from './chatgpt-auth';
import {getProfile} from '@/lib/account';
import {redirect} from 'next/navigation';
export const dynamic='force-dynamic';
export default async function Page(){const user=await getChatGPTUser();if(!user)redirect('/login');let profile;try{profile=await getProfile(user.userId)}catch{return <main className="empty"><h1>We could not load your account</h1><p>Please try again in a moment. Your saved data has not changed.</p><a className="button primary" href="/">Try again</a></main>}if(!profile)redirect('/signup');return <BachatApp isAdmin={isAdmin(user)} signedIn={true} signInUrl={chatGPTSignInPath('/')} initialTab={profile.role==='seller'?'seller':'discover'}/>;}
