# BachatBite source export

Live app: https://bachatbite-campus.aaaf5282105.chatgpt.site
Admin: https://bachatbite-campus.aaaf5282105.chatgpt.site/admin
Source commit: 3f64198012e10305fa97c13fada4071812c66827
Exported 4 October 2026, after the owner admin dashboard deployment.

## Upload to GitHub
Extract this ZIP and upload the contents of the BachatBite folder to your repository. Uploading only the ZIP or pasting the live URL does not create a browsable source repository. Keep the included folders and configuration files together. Add the live app URL to your repository description.

## Current functionality
ChatGPT sign-in, saved profiles, stores and food listings, photos, search/filtering, reservations, cancellation, seller pickup verification, local ML listing assistant and an owner-only searchable admin dashboard for users, restaurants, listings and orders.

ADMIN_EMAIL is a server-side runtime setting that controls admin access. The hosted version already has it configured. No secrets or live customer records are included in this source export. Database migrations are included, not the live database.

## Hosting requirements
This is a full-stack Sites/Cloudflare application, not a static GitHub Pages site. Uploading to GitHub stores the source; it does not move the live database, authentication or photo storage. A separate deployment needs compatible Worker hosting, D1, R2 and a trusted authentication integration. The current platform authentication headers must never be accepted directly from arbitrary clients on a different host.

## Verification and limits
The production build, TypeScript checks and admin policy/query tests passed. Earlier core API integration checks passed. A fresh browser walkthrough was unavailable. Payment is in person; online payments and delivery are not implemented. The dashboard provides read-only reporting, not moderation.

The original README includes an earlier private/in-progress delivery note; the current hosted app is public as of this export. Public access does not remove account sign-in or owner-only admin restrictions.
