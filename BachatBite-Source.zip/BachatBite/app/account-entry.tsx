import {getChatGPTUser,chatGPTSignInPath} from './chatgpt-auth';
import {getProfile} from '@/lib/account';
import AccountUI from './account-ui';
export default async function AccountEntry({mode}:{mode:'login'|'signup'}){const user=await getChatGPTUser();let profile=null,error='';try{if(user)profile=await getProfile(user.userId)}catch{error='Account service is temporarily unavailable. Please refresh to try again.'}return <AccountUI mode={mode} user={user?{name:user.fullName||'',email:user.email}:null} hasProfile={!!profile} error={error} signInUrl={chatGPTSignInPath(mode==='signup'?'/signup':'/')} />}
