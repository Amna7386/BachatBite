import {database} from './db';
export type Profile={user_id:string;name:string;role:'customer'|'seller';created:string};
export async function getProfile(userId:string){return database().prepare('SELECT user_id,name,role,created FROM profiles WHERE user_id=?').bind(userId).first<Profile>();}
