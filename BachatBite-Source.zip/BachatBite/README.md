# BachatBite

A mobile-friendly surplus food reservation app for a student project.

## Working features
- Dedicated Login and Create Account pages, ChatGPT sign-in and required persistent profile setup.
- New users choose a display name and starting role; existing reservations and stores retain the same owner identity.
- Store profiles, food listings, photo uploads and area/category/search filters.
- Durable Cloudflare D1 records and R2 photo storage.
- Atomic stock availability checks, reservations, price snapshots, cancellations.
- Seller-owned pickup verification with an eight-character code.
- Customer history, seller pickup queue, collected-order totals.
- Explicitly labelled sample data, loaded on demand for presentation.

## AI assistant
Works without a plugin or API key. A small supervised multinomial Naive Bayes classifier trained on labelled English/Roman Urdu food descriptions suggests Bakery, Meals or Snacks. Deterministic extraction fills explicit quantities/prices. This is not a generative language model; seller review is required, especially for uncertain categories, ingredients and pickup times. No safety/allergen information is inferred. Training examples and implementation are in `lib/local-assistant.ts`.

An optional hosted `OPENAI_API_KEY` enables language-model extraction through the existing server endpoint. Default model: `gpt-4.1-mini`. Keys must never go in client code or Git.

## Demo in five steps
1. Sign in, create your BachatBite profile and click **Load sample deals** on Discover.
2. Open a deal, reserve one portion, and copy its code from My pickups.
3. Open Seller studio and use Verify pickup on the matching reservation.
4. Enter the customer's code and confirm collection.
5. Show updated customer savings and seller collected value. Sample transactions are not real purchases.

For your own content, add a store in Seller studio, then New listing. Prices are whole PKR. Pickup inputs use device timezone; displayed times use Asia/Karachi.

## Architecture
Next-compatible React/Vinext UI; server API routes; Cloudflare D1 + generated Drizzle migrations; R2 uploads. Platform sign-in supplies a stable server-side user identity. Every mutation checks identity and ownership. Available inventory is derived from total listing quantity minus reserved/collected quantities; a single INSERT…SELECT validates stock atomically.

## Verification
TypeScript check and production build pass. `tests/smoke.py` contains local-only integration tests for identity, ownership, concurrent last-item reservations, persistence, cancellation, pickup codes, repeated collection, sample data and local-ML assistance. The test identity headers simulate the production dispatcher only against local preview; do not send them to a production site. Browser visual QA was unavailable in this environment.

## Boundaries
First release is owner-private until sharing is explicitly changed. Payment happens in person. No payment gateway, delivery, food-safety certification, independent email/password signup or admin moderation workflow is included in the one-day scope. Sample listings use illustrative stock photography; real sellers should upload accurate photos and provide ingredient/allergen details.

## Team roles
1. Product setup, integration, deployment.
2. Customer interface.
3. Seller interface.
4. Database, identity and reservations.
5. AI integration, testing and presentation.

## Development
Install the locked dependencies, generate migrations with `npm run db:generate` after schema changes, and build with `npm run build`. Use the Sites workflow for publishing; keep `.openai/hosting.json` associated with this existing project. Store runtime secrets in hosted environment settings. Photo attribution is included at `public/food/ATTRIBUTION.md`.

## Local Windows quick start
Use Node.js 22.13 or newer. Extract the ZIP, open its folder in VS Code and run:

```powershell
npm ci
npm run build
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0000_safe_goliath.sql
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0001_round_zaladane.sql
npm run dev
```
Open the local URL printed by the development server. The portable development profile provides a local sign-in simulation; it is never used in production. The ZIP intentionally excludes the managed runtime profile, installed packages, test database and secrets. Local database setup above is for the first run only.

## Delivery status
The application builds and its core API checks pass. Hosting publication is in progress; verify the live URL in the final delivery message. The local ML assistant works without external connections. This repository contains the source for the private hosted BachatBite app.
