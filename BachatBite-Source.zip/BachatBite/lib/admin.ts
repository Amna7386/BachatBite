import {env} from 'cloudflare:workers';
import {isAdminEmail} from './admin-policy';
export function isAdmin(user: {email:string} | null): boolean {
  return !!user && isAdminEmail(user.email, (env as unknown as Record<string,unknown>).ADMIN_EMAIL);
}
