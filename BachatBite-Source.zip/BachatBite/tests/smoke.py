"""Local HTTP integration checks. Never target the deployed Site."""
import json,urllib.request,urllib.error,concurrent.futures,datetime
BASE='http://127.0.0.1:4173'
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
def request(action=None,user='qa-seller',route='/api/app'):
 headers={'Content-Type':'application/json'}
 if user:headers.update({'oai-authenticated-user-id':user,'oai-authenticated-user-email':user+'@example.test'})
 body=json.dumps(action).encode() if action is not None else None
 try:
  r=opener.open(urllib.request.Request(BASE+route,data=body,headers=headers),timeout=35)
  return r.status,json.load(r)
 except urllib.error.HTTPError as e:return e.code,json.load(e)
def ok(condition,label):
 assert condition,label
 print('PASS:',label)
status,_=request(user=None);ok(status==401,'anonymous requests blocked')

import uuid
new_user='qa-new-'+uuid.uuid4().hex[:8]
status,_=request(user=new_user);ok(status==403,'signed-in user must finish signup before app access')
status,_=request({'name':'Test','role':'customer'},user=None,route='/api/account');ok(status==401,'signup requires verified identity')
status,_=request({'name':'','role':'admin'},user=new_user,route='/api/account');ok(status==400,'invalid signup data rejected')
status,d=request({'name':'Test Customer','role':'customer','userId':'someone-else'},user=new_user,route='/api/account');ok(status==200 and d['profile']['user_id']==new_user,'signup binds profile to server identity')
status,d=request({'name':'Overwrite','role':'seller'},user=new_user,route='/api/account');ok(status==200 and d['profile']['name']=='Test Customer','duplicate signup does not overwrite profile')
status,d=request(user=new_user);ok(status==200 and d['user']['name']=='Test Customer','saved profile unlocks account on later request')
for u in ['qa-seller','qa-outsider','qa-customer-1','qa-customer-2','qa-demo']:
 status,_=request({'name':'QA Tester','role':'seller' if u=='qa-seller' else 'customer'},user=u,route='/api/account')
 assert status==200

status,d=request({'action':'store','name':'QA store','area':'QA','address':'Test address','contact':'Test contact'})
ok(status==200,'seller creates store');sid=d['id']
now=datetime.datetime.now(datetime.timezone.utc)
listing={'action':'listing','store_id':sid,'title':'QA last portion','description':'Test only','category':'Snacks','price':100,'original_price':200,'quantity':1,'ingredients':'Test ingredients','photo':'/food/sandwich.jpg','start':(now-datetime.timedelta(minutes=2)).isoformat(),'end':(now+datetime.timedelta(hours=2)).isoformat()}
status,_=request(listing,'qa-outsider');ok(status==403,'other seller cannot publish to store')
status,d=request(listing);ok(status==200,'seller publishes listing');lid=d['id']
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 results=list(pool.map(lambda u:request({'action':'reserve','listing_id':lid,'quantity':1},u),['qa-customer-1','qa-customer-2']))
ok(sorted(x[0] for x in results)==[200,409],'simultaneous reservations cannot oversell')
i=next(i for i,x in enumerate(results) if x[0]==200);customer='qa-customer-'+str(i+1);reservation=results[i][1]
status,d=request(user=customer);ok(any(o['id']==reservation['id'] for o in d['orders']),'reservation survives reload')
status,d=request(user='qa-outsider');ok(not any(o['id']==reservation['id'] for o in d['orders']),'orders private to customer')
status,_=request({'action':'collect','id':reservation['id'],'code':reservation['code']},'qa-outsider');ok(status==400,'wrong seller cannot collect')
status,_=request({'action':'collect','id':reservation['id'],'code':'WRONG123'});ok(status==400,'wrong pickup code rejected')
status,_=request({'action':'cancel','id':reservation['id']},customer);ok(status==200,'customer cancellation works')
status,d=request({'action':'reserve','listing_id':lid,'quantity':1},customer);ok(status==200,'cancelled portion released');reservation=d
status,_=request({'action':'collect','id':reservation['id'],'code':reservation['code']});ok(status==200,'correct seller and code complete collection')
status,_=request({'action':'collect','id':reservation['id'],'code':reservation['code']});ok(status==400,'double collection prevented')
status,_=request({'action':'reserve','listing_id':lid,'quantity':1},customer);ok(status==409,'collected stock remains unavailable')
status,_=request({'text':'8 sandwiches 120 rupay each'},route='/api/ai');ok(status==200 and _['mode']=='local-ml' and _['draft']['quantity']==8 and _['draft']['price']==120,'local ML assistant works without plugin or API key')
status,_=request({'action':'seed'},user='qa-demo');ok(status==200,'labelled sample deals seed')
status,d=request(user='qa-demo');ok(len(d['stores'])>=1,'sample store persists')
