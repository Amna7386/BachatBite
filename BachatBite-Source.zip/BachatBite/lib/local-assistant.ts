/** A small supervised multinomial Naive Bayes model, trained on labelled
 * English/Roman Urdu food descriptions. Numeric fields use deterministic
 * extraction, not a language model. All drafts require seller review. */
const examples: Record<string,string[]> = {
 Bakery:[
 'butter croissant flaky baked pastry', 'fresh bread loaf sourdough bakery',
 'chocolate cake slices cupcakes muffin', 'cookies biscuits bakery box',
 'cinnamon rolls danish pastries', 'bakery ki double roti bread',
 'cake ke slices aur cream pastry', 'biscuit cookies ka packet',
 'croissant box butter pastry', 'banana muffins baked loaf',
 'donuts doughnuts glazed bakery', 'patties puff pastry bakery'
 ],
 Meals:[
 'chicken biryani rice meal bowl', 'vegetable pulao chawal rice lunch',
 'dal roti curry dinner plate', 'chicken karahi naan meal',
 'pasta spaghetti lunch dinner portion', 'daal chawal lunch box',
 'biryani ke dabbe chicken rice', 'sabzi roti ka khana',
 'pulao ki plate chawal', 'beef curry with rice',
 'vegetable rice bowl meal', 'chana masala dal lunch'
 ],
 Snacks:[
 'sandwich sandwiches vegetable toasted pack', 'burger burgers bun snack',
 'samosa samosay pakora pakoray snack', 'fries potato chips snack',
 'wrap wraps roll rolls sandwich', 'fruit salad chaat bowl',
 'sandwich ke packs vegetable', 'samosay aur pakoray',
 'burger aur fries pack', 'chicken roll wrap snack',
 'pizza slice cheese snack', 'dahi bhallay chaat snack'
 ]
};
const stop=new Set('a an the of in with and aur ke ki ka hain hai ha ko ko aaj today fresh box pack packs plate portion portions rupay rupees rs pkr per each available pickup se tak shaam subah baje'.split(' '));
function tokens(s:string){return s.toLowerCase().normalize('NFKC').replace(/[^a-z\s]/g,' ').split(/\s+/).filter(w=>w.length>1&&!stop.has(w));}
const vocab=new Set<string>(),counts:Record<string,Map<string,number>>={},totals:Record<string,number>={};
for(const [label,docs] of Object.entries(examples)){counts[label]=new Map();totals[label]=0;for(const doc of docs)for(const word of tokens(doc)){vocab.add(word);counts[label].set(word,(counts[label].get(word)||0)+1);totals[label]++;}}
export function classifyFood(text:string){const words=tokens(text).filter(t=>vocab.has(t));if(!words.length)return {category:null,confidence:0};const scores=Object.keys(examples).map(label=>({label,score:words.reduce((s,w)=>s+Math.log(((counts[label].get(w)||0)+1)/(totals[label]+vocab.size)),Math.log(1/3))})).sort((a,b)=>b.score-a.score);const denominator=scores.reduce((sum,s)=>sum+Math.exp(s.score-scores[0].score),0);const confidence=1/denominator;return {category:confidence>=0.48?scores[0].label:null,confidence:Math.round(confidence*100)/100};}
export function localDraft(text:string){
 const classification=classifyFood(text);
 const priceAfter=text.match(/(?:rs\.?|pkr|price\s*[:=]?)\s*(\d{1,6})/i);
 const priceBefore=text.match(/(\d{1,6})\s*(?:rupay|rupees|rupe|rs\b|pkr\b)/i);
 const original=text.match(/(?:original|regular|pehle)\s*(?:price\s*)?(?:rs\.?|pkr)?\s*[:=]?\s*(\d{1,6})/i);
 // Do not mistake a clearly marked original price for the deal price.
 const dealText=text.replace(/(?:original|regular|pehle)\s*(?:price\s*)?(?:rs\.?|pkr)?\s*[:=]?\s*\d{1,6}\s*(?:rupay|rupees)?/ig,'');
 const deal=dealText.match(/(?:rs\.?|pkr|price\s*[:=]?)\s*(\d{1,6})/i)||dealText.match(/(\d{1,6})\s*(?:rupay|rupees|rupe|rs\b|pkr\b)/i);
 const quantity=text.match(/(?:quantity|qty|portions?)\s*[:=]?\s*(\d{1,3})/i)||text.match(/(?:^|[,;]\s*|aaj\s+)(\d{1,3})\s+(?=[a-z])/i);
 const first=text.split(/[,;\n]/)[0].trim().replace(/^(?:aaj\s+)?\d+\s+/i,'').replace(/\s+(?:hain|hai|ha|bachay|bache|available)\b.*$/i,'').slice(0,100);
 const pickup=text.match(/(?:pickup|shaam|subah|evening|collect)\b[^\n]*/i);
 return {draft:{title:first?first[0].toUpperCase()+first.slice(1):null,description:text.slice(0,700),category:classification.category,quantity:quantity?Number(quantity[1]):null,price:deal?Number(deal[1]):null,original_price:original?Number(original[1]):null,ingredients:null,pickup_note:pickup?.[0]||null},mode:'local-ml',categoryConfidence:classification.confidence,note:'A small local ML model suggests the category; rules extract numbers. Review all fields. Ingredients, allergens and exact pickup times must be entered by the seller.'};
}
