import { env } from 'cloudflare:workers';
export function database(){if(!env.DB)throw new Error('Database unavailable. Please try again shortly.');return env.DB;}
export function bucket(){if(!env.BUCKET)throw new Error('Photo storage unavailable. Please try again shortly.');return env.BUCKET;}
export const availability="(l.quantity - COALESCE((SELECT SUM(r.quantity) FROM reservations r WHERE r.listing_id=l.id AND r.status IN ('reserved','collected')),0))";
