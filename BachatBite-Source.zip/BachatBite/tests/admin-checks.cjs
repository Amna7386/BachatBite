// Run compiled production route logic with isolated auth/database boundaries.
const ts=require('typescript'),fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),cp=require('node:child_process');
function compile(file,bindings={}){const exports={};vm.runInNewContext(ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText,{exports,require:key=>{if(!(key in bindings))throw Error(key);return bindings[key]},Response,URL});return exports}
const {isAdminEmail}=compile('lib/admin-policy.ts');
assert.equal(isAdminEmail('owner@example.test',undefined),false);
assert.equal(isAdminEmail('', ''),false);
assert.equal(isAdminEmail('intruder@example.test','owner@example.test'),false);
assert.equal(isAdminEmail(' OWNER@example.test ','owner@example.test'),true);
let user=null,queries=[],dbCalls=0;
const db={prepare(sql){dbCalls++;return {args:[],bind(...args){this.args=args;return this},async all(){queries.push({sql,args:this.args});return {results:[]}},async first(){queries.push({sql,args:this.args});return {count:0}}}}};
const {GET}=compile('app/api/admin/route.ts',{'@/app/chatgpt-auth':{getChatGPTUser:async()=>user},'@/lib/admin':{isAdmin:u=>u&&isAdminEmail(u.email,'owner@example.test')},'@/lib/db':{database:()=>db}});
(async()=>{
 let r=await GET(new Request('https://test/api/admin'));assert.equal(r.status,401);assert.equal(dbCalls,0);
 user={email:'intruder@example.test'};r=await GET(new Request('https://test/api/admin'));assert.equal(r.status,403);assert.equal(dbCalls,0);
 user={email:'owner@example.test'};r=await GET(new Request('https://test/api/admin?kind=bad'));assert.equal(r.status,400);assert.equal(dbCalls,0);
 for(const kind of ['orders','users','stores','listings']){r=await GET(new Request('https://test/api/admin?kind='+kind));assert.equal(r.status,200);assert.equal(r.headers.get('Cache-Control'),'private, no-store')}
 r=await GET(new Request('https://test/api/admin?kind=users&page=2&q='+encodeURIComponent("' OR 1=1 --")));assert.equal(r.status,200);assert.equal(queries.at(-3).args[1],25);assert.equal(queries.at(-3).args[0],"%' OR 1=1 --%");
 const result=cp.spawnSync('python',['-c',`import sqlite3,json,sys,pathlib
c=sqlite3.connect(':memory:')
for p in sorted(pathlib.Path('drizzle').glob('*.sql')): c.executescript(p.read_text())
for q in json.load(sys.stdin): c.execute(q['sql'],q['args']).fetchall()
print('PASS: all report, count, summary and search queries execute against migrated SQLite schema')`],{input:JSON.stringify(queries),encoding:'utf8'});
 assert.equal(result.status,0,result.stderr);console.log(result.stdout.trim());console.log('PASS: fail-closed admin policy; anonymous and non-owner denied before DB access; report whitelist; private cache headers; parameterized search and pagination');
})().catch(e=>{console.error(e);process.exit(1)});
